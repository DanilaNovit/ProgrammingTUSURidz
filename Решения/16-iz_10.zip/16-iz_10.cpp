// Для хранения данных о ноутбуках описать структуру вида (при необходимости дополнив ее):
// struct NOTEBOOK{
// struct disp_res{ // разрешающая способность дисплея
// int х; // по горизонтали
// int у; // по вертикали
// };
// int f; // частота регенерации
// float d; // размер диагонали дисплея
// int price; // цена
// ИЗ 16
// char model[21]; // наименование
// }
// Написать функцию, которая читает данные о ноутбуках из файла note.txt (см.
// ниже) в структуру приведенного вида. Написать функцию, которая записывает
// содержимое структуры в конец бинарного файла. Структура бинарного файла: первые
// два байта (целое) — число записей в файле; далее записи в формате структуры
// NOTEBOOK.
// Написать программу, в которой на основе разработанных функций осуществляется запись
// в двоичный файл данных только о тех ноутбуках, объем видеопамяти
// которых 2 Мбайт, отсортированных в порядке уменьшения тактовой частоты процессора.

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct NOTEBOOK
{
  struct size_s
  {
    float x;
    float y;
    float z;
  };

  char model[21];
  int price;
  float weight;
  int ghz;
  int video_memory;
  size_s size;
} notebook;

// Возвращает кал-во записей в note.txt
int get_number_of_records(FILE* file)
{
  if (!file) return -1;

  fseek(file, 0, SEEK_SET);

  int number_of_records = 0;
  char buf[152];

  while (!feof(file))
  {
    ++number_of_records;
    fgets(buf, 152, file);
  }

  fseek(file, 0, SEEK_SET);

  return number_of_records;
}

// Считывает 1-ю запись из note.txt и возвращает в виде структуры
notebook* read_record(FILE* file)
{
  if (!file || feof(file)) return NULL;

  char buf[35];
  fgets(buf, 21, file);

  int i = 19;

  while (buf[i] == ' ')
  {
    --i;
  }

  if (i != 19)
  {
    buf[i + 1] = 0;
  }

  notebook* note = (notebook*) malloc(sizeof(notebook));

  strcpy(note->model, buf);
  note->price = atoi(fgets(buf, 5, file));
  note->weight = atof(fgets(buf, 5, file));

  fgetc(file);
  note->size.x = atof(fgets(buf, 5, file));
  fgetc(file);
  note->size.y = atof(fgets(buf, 5, file));
  fgetc(file);
  note->size.z = atof(fgets(buf, 5, file));

  note->ghz = atoi(fgets(buf, 5, file));

  fgets(buf, 10, file);

  note->video_memory = atoi(fgets(buf, 2, file));

  fgets(buf, 23, file);

  return note;
}

// Считывает все записи из note.txt и возвращает массив структур
notebook** read_records(FILE* file, int* note_list_length)
{
  if (!file) return NULL;

  fseek(file, 0, SEEK_SET);

  *note_list_length = get_number_of_records(file);
  notebook** note_list = (notebook**) malloc(sizeof(notebook*) * *note_list_length);

  for (int i = 0; i < *note_list_length; ++i)
  {
    note_list[i] = read_record(file);
  }

  fseek(file, 0, SEEK_SET);

  return note_list;
}

// Считывает только те записи,  видео память в которых равна 2
notebook** read_records_2_mb(FILE* file, int* note_list_length)
{
  if (!file) return NULL;

  fseek(file, 0, SEEK_SET);

  *note_list_length = get_number_of_records(file);
  notebook** note_list = (notebook**) malloc(sizeof(notebook*) * *note_list_length);

  notebook* note_buf = 0;

  int real_length = 0;

  for (int i = 0; i < *note_list_length; ++i)
  {
    note_buf = read_record(file);

    if (note_buf->video_memory == 2)
    {
      note_list[real_length] = note_buf;
      ++real_length;
    }
  }

  *note_list_length = real_length;
  note_list = (notebook**) realloc(note_list, sizeof(notebook) * real_length);

  fseek(file, 0, SEEK_SET);

  return note_list;
}


// Записываем массив структур notebook в data.bin
int write_list_to_bin(FILE* file, notebook** note_list, int note_list_length)
{
  if (!file) return -1;

  fseek(file, 0, SEEK_SET);

  fwrite(&note_list_length, sizeof(int), 1, file);

  for (int i = 0; i < note_list_length; ++i)
  {
    fwrite(note_list[i], sizeof(notebook), 1, file);
  }

  fseek(file, 0, SEEK_SET);

  return 0;
}

// Записывает структуру notebook в конец data.bin
int write_record_to_end_bin(FILE* file, notebook* note)
{
  if (!file) return -1;

  fseek(file, 0, SEEK_SET);

  int note_list_length = 0;
  fread(&note_list_length, sizeof(int), 1, file);

  ++note_list_length;
  fseek(file, 0, SEEK_SET);
  fwrite(&note_list_length, sizeof(int), 1, file);

  fseek(file, 0, SEEK_END);
  fwrite(note, sizeof(notebook), 1, file);

  fseek(file, 0, SEEK_SET);

  return 0;
}

// Выводит в консоль все структуры из data.bin
int print_records(FILE* file)
{
  if (!file) return -1;

  fseek(file, 0, SEEK_SET);

  int note_list_length = 0;
  fread(&note_list_length, sizeof(int), 1, file);
  
  notebook note_list[note_list_length];
  fread(&note_list, sizeof(notebook), note_list_length, file);

  printf("Number of records: %d\n\n", note_list_length);

  for (int i = 0; i < note_list_length; ++i)
  {
    printf("Name: %s\n", note_list[i].model);
    printf("Price: %d\n", note_list[i].price);
    printf("Weight: %.2f\n", note_list[i].weight);
    printf("X: %.2f\n", note_list[i].size.x);
    printf("Y: %.2f\n", note_list[i].size.y);
    printf("Z: %.2f\n", note_list[i].size.z);
    printf("Ghz: %d\n", note_list[i].ghz);
    printf("Video memory: %d\n\n", note_list[i].video_memory);
  }

  fseek(file, 0, SEEK_SET);
  return 0;
}

// Фун-я сравнения структур notebook мужду собой по частоте процессора
int price_comp (const void* a, const void* b)
{
  if (((notebook*) a)->ghz > ((notebook*) b)->ghz)
  {
    return 1;
  } else if (((notebook*) a)->ghz < ((notebook*) b)->ghz)
  {
    return -1; 
  }

  return 0;
}

// Сортирует структуры в data.bin по возрастанию частоты процессора
int sort(FILE* file)
{
  if (!file) return -1;

  int note_list_length = 0;
  fread(&note_list_length, sizeof(int), 1, file);
  
  notebook note_list[note_list_length];
  fread(&note_list, sizeof(notebook), note_list_length, file);

  qsort(note_list, note_list_length, sizeof(notebook), price_comp);

  fseek(file, 0, SEEK_SET);
	
  fwrite(&note_list_length, sizeof(int), 1, file);
  fwrite(note_list, sizeof(notebook), note_list_length, file);

  fseek(file, 0, SEEK_SET);
  return 0;
}

int main()
{
  // Открываем файлы
  char source_filename[] = "note.txt";
  FILE* source_file = fopen(source_filename, "r");

  char bin_filename[] = "data.bin";
  FILE* bin_file = fopen(bin_filename, "w+b");

  // Считываем записи, видео память в которых равна 2
  int note_list_length = 0;
  notebook** note_list = read_records_2_mb(source_file, &note_list_length);

  // Записываем записи в data.bin
  write_list_to_bin(bin_file, note_list, note_list_length);
  // Сортируем data.bin
  sort(bin_file);
  // Выводим в консоль data.bin
  print_records(bin_file);

  // Очищаем память
  for (int i = 0; i < note_list_length; ++i)
  {
    free(note_list[i]);
  }
  free(note_list);

  // Закрываем файлы
  fclose(source_file);
  fclose(bin_file);
}
