// Даны символьные файлы F и G. Определить, совпадают ли эти файлы посимвольно.
// Если нет, то получить номер первой несовпадающей пары символов.

#include <stdio.h>

int get_file_size(FILE* file)
{
  if (file == NULL)
  {
    return -1;
  }

  int file_size = 0;

  while (getc(file) != EOF)
  {
    ++file_size;
  }

  fseek(file, 0, SEEK_SET);

  return file_size;
}

int main()
{
  char f_file_name[] = "F.txt";
  char g_file_name[] = "G.txt";

  FILE* f_file = fopen(f_file_name, "r");
  FILE* g_file = fopen(g_file_name, "r");

  if (f_file == NULL)
  {
    printf("Файл F не найден\n");
    return 0;
  }

  if (g_file == NULL)
  {
    printf("Файл G не найден\n");
    return 0;
  }

  bool files_are_different = get_file_size(f_file) != get_file_size(g_file);

  int char_number = -1;
  int count_char = 0;
  bool last_chars_dif = false;
  char f_char = 0;
  char g_char = 0;

  while ((f_char = getc(f_file)) != EOF &&
         (g_char = getc(g_file)) != EOF)
  {
    if (f_char != g_char && last_chars_dif)
    {
      char_number = count_char;
      break;
    }

    if (f_char != g_char)
    {
      last_chars_dif = true;
      files_are_different = true;
    } else
    {
      last_chars_dif = false;
    }

    ++count_char;
  }

  fclose(f_file);
  fclose(g_file);

  if (char_number != -1)
  {
    printf("Номер первой несовпадающей пары символов: %d\n",
                                              char_number);

    return 0;
  }

  if (files_are_different)
  {
    printf("Файлы разные, но пара символов не найдена\n");
    return 0;
  }

  printf("Файлы совпадают\n");
}
